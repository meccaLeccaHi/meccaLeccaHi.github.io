from flask import render_template, flash, redirect
from app import app
from app.forms import LocateForm


@app.route('/')
@app.route('/index')
def index():
    user = 'Jerry'
    
    return render_template('index.html', user=user)


# 'Locate ski resorts' view
@app.route('/locate', methods=['GET', 'POST'])
def locate():
	form = LocateForm()
	if form.validate_on_submit():
		
		# Provide user feedback
		flash('Finding ski resorts closest to: {}'.format(form.address.data))
		return redirect('/index')

	# Render webpage
	return render_template('locate.html', title="Find resorts", form=form)
