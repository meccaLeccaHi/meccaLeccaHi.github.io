from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField
from wtforms.validators import DataRequired


# Define class for location form
class LocateForm(FlaskForm):
	# Create address field
	address = StringField('Enter address below', validators=[DataRequired()])
	# Create submission button
	submit = SubmitField('Submit')
